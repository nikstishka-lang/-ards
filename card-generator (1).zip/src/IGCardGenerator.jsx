import React, { useRef, useState } from "react";
export default function IGCardGenerator() {
  return <div style={{padding: '50px', textAlign:'center'}}>Ваш генератор карточек здесь</div>;
}